const products = [
    {
        id: 1,
        name: "Laptop",
        price: 1200
    },
    {
        id: 2,
        name: "Phone",
        price: 800
    },
    {
        id: 3,
        name: "Headphones",
        price: 200
    }
];

let cart = [];
let searchQuery = "";

const productsContainer = document.getElementById("products-container");
const cartItemsContainer = document.getElementById("cart-items");
const cartCount = document.getElementById("cart-count");
const cartTotal = document.getElementById("cart-total");
const searchInput = document.getElementById("search-input");
const emptyCartBtn = document.getElementById("empty-cart-btn");
const darkModeBtn = document.getElementById("dark-mode-btn");

searchInput.addEventListener("input", (e) => {
    searchQuery = e.target.value.trim().toLowerCase();
    renderProducts();
});

emptyCartBtn.addEventListener("click", () => {
    cart = [];
    renderCart();
});

darkModeBtn.addEventListener("click", () => {
    document.body.classList.toggle("dark");
});

function renderProducts() {
    productsContainer.textContent = "";

    const filteredProducts = products.filter(product => 
        product.name.toLowerCase().includes(searchQuery)
    );

    if (filteredProducts.length === 0) {
        const p = document.createElement("p");
        p.textContent = "Товарів не знайдено";
        productsContainer.appendChild(p);
        return;
    }

    filteredProducts.forEach(product => {
        const card = document.createElement("div");
        card.className = "product-card";

        const info = document.createElement("div");
        
        const title = document.createElement("span");
        title.textContent = `${product.name} - ${product.price} $`;
        
        info.appendChild(title);

        const button = document.createElement("button");
        button.type = "button";
        button.textContent = "Add to cart";
        button.setAttribute("data-product-id", product.id);

        button.addEventListener("click", () => {
            addToCart(product.id);
        });

        card.appendChild(info);
        card.appendChild(button);
        productsContainer.appendChild(card);
    });
}

function addToCart(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;

    const cartItem = cart.find(item => item.id === productId);
    if (cartItem) {
        cartItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    }

    renderCart();
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    renderCart();
}

function renderCart() {
    cartItemsContainer.textContent = "";

    if (cart.length === 0) {
        const p = document.createElement("p");
        p.textContent = "Кошик порожній";
        cartItemsContainer.appendChild(p);
    } else {
        cart.forEach(item => {
            const cartItemEl = document.createElement("div");
            cartItemEl.className = "cart-item";

            const info = document.createElement("span");
            info.textContent = `${item.name} (${item.price} $) x ${item.quantity}`;

            const removeBtn = document.createElement("button");
            removeBtn.type = "button";
            removeBtn.className = "danger-btn";
            removeBtn.textContent = "Видалити";

            removeBtn.addEventListener("click", () => {
                removeFromCart(item.id);
            });

            cartItemEl.appendChild(info);
            cartItemEl.appendChild(removeBtn);
            cartItemsContainer.appendChild(cartItemEl);
        });
    }

    const totalCount = cart.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);

    cartCount.textContent = totalCount;
    cartTotal.textContent = totalPrice;
}

renderProducts();
renderCart();
